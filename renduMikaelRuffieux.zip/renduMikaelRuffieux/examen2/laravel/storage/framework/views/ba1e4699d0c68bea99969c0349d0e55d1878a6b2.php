<!DOCTYPE html>
<html>
    <body>
        Ton prénom est <?php echo e($results['prenom']); ?>.<br>
        Tu as <?php echo e($results['age']); ?> ans.<br>
        Tu connais <?php echo sizeof($results['q1']);?> language(s) de programmation.<br>
        Ton genre : <?php echo e($results['genre']); ?>.<br>
        Tes préférences :<br>
        <?php $__currentLoopData = $results['preferences']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            - <?php echo e($preference); ?> <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
</html><?php /**PATH /Users/mruffieux/Documents/_HEIG-VD/DevProdMed/examen2/laravel/resources/views/resultat.blade.php ENDPATH**/ ?>